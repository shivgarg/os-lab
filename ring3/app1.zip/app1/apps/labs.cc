#include "apps/labs.h"

#include "x86/except.h"

uint32_t f2(uint8_t x, uint8_t y, uint8_t z)
{
  // hoh_debug("HELLO1HELLO1HELLO1HELLO1HELLO1HELLO1HELLO1HELLO1HELLO1HELLO1HELLO1");
  // hoh_debug("x="<<x<<" "<<"y="<<y<<" "<<"z="<<z<<" ADDR="<<((2u<<30) + (((uint32_t)x)*256u*256u + ((uint32_t)y)*256u + ((uint32_t)z))*4u));
  // hoh_debug("HELLO1HELLO1HELLO1HELLO1HELLO1HELLO1HELLO1HELLO2HELLO2HELLO2HELLO2");


  return *(int *)((2u<<30) + (((uint32_t)x)*256u*256u + ((uint32_t)y)*256u + ((uint32_t)z))*4u);
}

uint32_t sum_nbrs(uint8_t x, uint8_t y, uint8_t z)
{
  uint32_t sum = 0;
  // int d = 1;
  // for (int i = 0; i < d; ++i)
  // {
  //   for (int j = 0; j < d; ++j)
  //   {
  //     for (int k = 0; k < d; ++k)
  //     {
  //       sum += f2(x+i,y+j,z+k);
  //       hoh_debug("x+i=" << x+i);
  //       hoh_debug("y+j=" << y+j);
  //       hoh_debug("z+k=" << z+k);
  //       hoh_debug("f2(x+i,y+j,z+k)=" << f2(x+i,y+j,z+k));
  //       // hoh_assert(f2(x+i,y+j,z+k)==1,"XXX");
  //       hoh_debug("OVER");
  //     }
  //   }
  // } 
    int add=f2(x,y,z);
    // hoh_debug("x=" << x<<" y="<<y<<" z="<<z);
    // hoh_debug("f2(x,y,z)=" << add);
    // // hoh_assert(f2(x+i,y+j,z+k)==1,"XXX");
    // hoh_debug("OVER");
  return add;
}

void for_each()
{
  int sum=0;
  for (int i = 0; i <= 255; ++i)
  {
    for (int j = 0; j <= 255; ++j)
    {
      for (int k = 0; k <= 255; ++k)
      {
      	int add=sum_nbrs(i,j,k);
        // hoh_assert(add==8,"XXX");
        sum+=sum_nbrs(i,j,k);
      }
    }
  }
  hoh_debug("SUM="<<(uint32_t)sum);
}
//
// app step
//
static void apps_loop_step(int rank, addr_t& main_stack, apps_t& apps, uint32_t* systemcallmmio){
  hoh_debug("apps_loop_step");
  for_each();
  uint32_t ret1;
  uint32_t ret2;
  uint32_t ret3;
  xsyscall(systemcallmmio, 0x1, 0,0,0, ret1,ret2,ret3);
}



//
// reset
//
extern "C" void apps_reset(int rank, apps_t& apps, bitpool_t& pool4k, uint32_t* systemcallmmio){


  asm volatile ("nop ");

  // uint32_t ret1;
  // uint32_t ret2;
  // uint32_t ret3;

  // xsyscall(systemcallmmio, 0x9, 0,0,0, ret1,ret2,ret3);
  // hoh_debug("Allocated at: "<<ret1);
  // apps.fifo[0]=ret1;

  // xsyscall(systemcallmmio, 0x9, 0,0,0, ret1,ret2,ret3);
  // hoh_debug("Allocated at: "<<ret1);
  // apps.fifo[1]=ret1;

  // xsyscall(systemcallmmio, 0x9, 0,0,0, ret1,ret2,ret3);
  // hoh_debug("Allocated at: "<<ret1);
  // apps.fifo[2]=ret1;

  // xsyscall(systemcallmmio, 0x9, 0,0,0, ret1,ret2,ret3);
  // hoh_debug("Allocated at: "<<ret1);
  // apps.fifo[3]=ret1;

  // apps.head=0;
  // apps.tail=3;

  // addr_t varray=addr_t(2<<30);
  // if(ret1!=uintptr_t(varray)){
  //   xsyscall(systemcallmmio, 0x6, ret1,uintptr_t(varray),0, ret1, ret2, ret3);
  // }
  
  // hoh_debug("Testing ....");
  // *varray=0;
  // hoh_debug("Testing done....");

  // hoh_debug("Bomb..");
  // *(varray+(4<<20))=0;
  // hoh_debug("Bomb defused..");


  //..... print return values

  // xsyscall(systemcallmmio, 0x1, 0,0,0, ret1,ret2,ret3);



}


//
// main loop
//
extern "C" void apps_loop(int rank, addr_t* pmain_stack, apps_t* papps, uint32_t* systemcallmmio){
  addr_t& main_stack = *pmain_stack;
  apps_t& apps       = *papps;
  uint32_t esp;
  asm volatile ("mov %%esp,%0":"=r"(esp)::);
  for(;;){
    apps_loop_step(rank, main_stack, apps, systemcallmmio);
  }

}

