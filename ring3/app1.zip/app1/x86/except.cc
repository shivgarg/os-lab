#include "x86/except.h"
#include "x86/main.h"
#include "util/util.h"






extern "C" void handle_user_fault(usertrapframe_t& x){

  hoh_debug("user fault: rank="<<x.rank<<","<<x.masterro<<","<<x.masterrw<<","<<x.sharedrw
                               <<",num="<<x.num<<",ec="<<x.errorcode<<",esp="<<x.old_esp<<",eip="<<x.old_eip
                               <<",cr2="<<x.cr2);

  core_t* pcore=(core_t*) x.masterrw;
  core_t& core = *pcore;

  uint32_t new_page = (uint32_t)prevalign((addr_t)x.cr2,4<<20);
  uint32_t next_page = new_page + (4<<20);
  uint32_t address = new_page;
  
  hoh_debug("NEW PAGE="<<new_page);

  uint32_t ret1;
  uint32_t ret2;
  uint32_t ret3;

  if(pcore->apps.count==4){
    pcore->apps.head++;
    pcore->apps.head%=4;
    xsyscall(pcore->syscallmmio, 0x6, new_page, pcore->apps.fifo[pcore->apps.head],0, ret1,ret2,ret3);
    pcore->apps.fifo[pcore->apps.head]=new_page;
  }
  else{
    pcore->apps.head++;
    pcore->apps.head%=4;
    xsyscall(pcore->syscallmmio, 0x9, 0, 0, 0, ret1,ret2,ret3);
    xsyscall(pcore->syscallmmio, 0x6, new_page, ret1,0, ret1,ret2,ret3);
    pcore->apps.fifo[pcore->apps.head]=new_page;
    pcore->apps.count++;
  }

  uint32_t x_n = (new_page - (2u<<30))/(256u*256u*4u);
  uint32_t y_n = 0;
  uint32_t z_n = 0;
  
  hoh_debug("NEW_PAGE="<<new_page);
  hoh_debug("NEXT_PAGE="<<next_page<<"\n\n");

  while(address<next_page){
  	*(int *)((2<<30)+(x_n*256u*256u+y_n*256u+z_n)*4u) = 1;
  	z_n++;
  	y_n+=(z_n>>8);
  	z_n=(z_n)&(0xffu);
  	x_n+=(y_n>>8);
  	y_n=(y_n)&(0xffu);
  	address+=4;
  }
  pcore->apps.pf_count++;
  hoh_debug("Count = "<<pcore->apps.pf_count);
}